<template>
    <div>

    </div>
</template>
<script>
export default {
    name: 'userList',
    data(){
        return {
            users: [],
            isLoading: false,

        }
    },
    mounted(){

    },
    methods: {
        loadUsers(){

        }
    },

}
</script>
