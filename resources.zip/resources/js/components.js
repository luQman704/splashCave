import Vue from 'vue'
import App from './App.vue'

Vue.component('app', App);
